create procedure valuta_newDoc(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
P_Filial VARCHAR,
P_sABSID VARCHAR,
P_sCustomerName VARCHAR,
P_sCustomerINN VARCHAR,
P_sConvType VARCHAR,
P_sDocumentNumber VARCHAR,
P_dDocumentDate VARCHAR,
P_sCurrCodeDebet VARCHAR,
P_nAmountDebet VARCHAR,
P_sAccountDebet VARCHAR,
P_sDebetBankBIC VARCHAR,
P_sCurrCodeCredit VARCHAR,
P_nAmountCredit VARCHAR,
P_sAccountCredit VARCHAR,
P_sCreditBankBIC VARCHAR,
P_sChargeAccount VARCHAR,
P_nChargeType VARCHAR,
P_nRequestRate VARCHAR,
P_nRequestRateType VARCHAR,
P_sSenderOfficial VARCHAR,
P_sPhoneOfficial VARCHAR,
P_sDealType VARCHAR,
P_sOperCode VARCHAR,
P_sCurrDealInquiryNumber VARCHAR,
P_dCurrDealInquiryDate VARCHAR,
P_sTransferDocumentNumber VARCHAR,
P_dTransferDocumentDate VARCHAR,
P_sTransferAccount VARCHAR,
P_nTransferAmount VARCHAR,
P_sNote VARCHAR,
P_sGroundReceipts VARCHAR,
P_sFixInfo VARCHAR,
P_dDateInp VARCHAR,
P_nService VARCHAR,
P_RecordId VARCHAR,
P_sIP VARCHAR,
P_sKEYID VARCHAR
) as
begin
Refer := 648590;
Code := 0;
Name := 'Тест хранимки';
end;
/

