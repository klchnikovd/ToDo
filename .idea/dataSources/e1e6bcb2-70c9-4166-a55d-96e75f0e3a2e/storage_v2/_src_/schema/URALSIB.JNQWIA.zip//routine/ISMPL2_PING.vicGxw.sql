create procedure ISMPL2_PING(
ErrCode out INTEGER,
ErrText  out VARCHAR,
ErrSystemText  in out VARCHAR,
SYSTEM_REF  VARCHAR
) as
begin
ErrCode := 0;
ErrText := 'Ошибков нету';
ErrSystemText := 'Netu ERRORSOV';
end;
/

