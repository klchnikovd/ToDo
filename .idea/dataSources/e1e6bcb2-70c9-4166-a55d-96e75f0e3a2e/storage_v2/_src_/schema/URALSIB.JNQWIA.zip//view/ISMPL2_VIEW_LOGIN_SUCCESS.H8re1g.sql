create view ISMPL2_VIEW_LOGIN_SUCCESS as
select
    sys.user_name        AS uName,        -- системное имя сотрудника
		sys.user_ip          AS sIp,          -- IP адрес, с которого входил сотрудник
		max(changestamp)     AS dDate,        -- дата/время входа сотрудника
		employee.fullname    AS sFIO,         -- ФИО сотрудника организации
		company_ul.shortname AS sNameShort,   -- Краткое название ЮЛ в АБС
		company_ex.ext_ref   AS sABSID,       -- Код организации в АБС
		company_ex.inn       AS sInn,         -- ИНН организации
		CASE
		  WHEN length(company_ex.inn) = 12 THEN 2
		  WHEN length(company_ex.inn) = 10 OR length(company_ex.inn) = 5 THEN 1
    	  ELSE 0
    	END                 AS SType,         -- Тип: если если длина ИНН 12 то 2, длина ИНН 5 или 10 то 1 иначе 0
		(SELECT DBTIMEZONE as sTimeZone FROM DUAL) AS sTimeZone
  from ups_systemlog sys
  inner join ups_doc_subject employee ON (employee.username=sys.user_name and employee.subject_type=2)
  left join ups_subject_to_subject links ON employee.owner_id=links.subject_id
  left join ups_doc_subject company ON links.link_subject_id = company.owner_id
  left join bnk_usr_client company_ex ON company_ex.owner_id = company.owner_id
  left join bnk_usr_client_ul company_ul ON company_ul.owner_id = company.owner_id
  where operation_code = 'LOGIN_SUCCESS'    -- Только события успешного входа
  and changestamp > sysdate - 14            -- Только за последние 2 недели
  group by sys.user_name, sys.user_ip, employee.fullname, company_ul.shortname, company_ex.ext_ref, company_ex.inn
/

