create procedure platpor(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
P_Filial VARCHAR,
P_BssId VARCHAR,
P_sDocumentNumber VARCHAR,
P_dDocumentDate VARCHAR,
P_sPayer VARCHAR,
P_sPayerINN VARCHAR,
P_sPayerAccount VARCHAR,
P_sPayerBIC VARCHAR,
P_sPayerCorrAccount VARCHAR,
P_sReceiver VARCHAR,
P_sReceiverINN VARCHAR,
P_sReceiverAccount VARCHAR,
P_sReceiverBIC VARCHAR,
P_sReceiverCorrAccount VARCHAR,
P_nAmount VARCHAR,
P_sGround VARCHAR,
P_sPaymentUrgent VARCHAR,
P_dPayUntil VARCHAR,
P_sOperType VARCHAR,
P_sSendType VARCHAR,
P_sStat1256 VARCHAR,
P_sPayerKPP VARCHAR,
P_sReceiverKPP VARCHAR,
P_sCBCcode VARCHAR,
P_sOKATOcode VARCHAR,
P_sPayGrndParam VARCHAR,
P_sTaxPeriod VARCHAR,
P_sDocNumParam VARCHAR,
P_sDocDate VARCHAR,
P_sPayType VARCHAR,
P_sCodeUIP VARCHAR,
P_dDateInp VARCHAR,
P_RecordId VARCHAR,
P_sIsSuspect VARCHAR,
P_sSpecialInfo VARCHAR,
P_sAcceptCli VARCHAR,
P_nSignType VARCHAR,
P_sIP VARCHAR,
P_sKEYID VARCHAR
) as
begin
Refer := 112233;
Code := 0;
Name := 'Тест хранимки';
end;
/

