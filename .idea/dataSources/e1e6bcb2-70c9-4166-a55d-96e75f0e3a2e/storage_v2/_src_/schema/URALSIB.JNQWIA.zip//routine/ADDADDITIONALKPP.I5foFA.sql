create PROCEDURE addAdditionalKpp (kpp IN VARCHAR, client_id IN NUMERIC) IS
	gen_id         NUMERIC(15);
	BEGIN
		gen_id := ups_doc_seq.NEXTVAL;
		INSERT INTO ups_doc(id, createuser, changeuser, createstamp, changestamp, doc_status, doc_module, doc_type)
			VALUES(gen_id, 'system', 'system', SYSDATE, SYSDATE, 'new', 'ibankul', 'additional_kpp');
		INSERT INTO additional_kpp_ul(owner_id, client_id, kpp) VALUES(gen_id, client_id, kpp);
END addAdditionalKpp;
BEGIN
	FOR client IN (SELECT owner_id, kpp2, kpp3, kpp4 FROM bnk_usr_client)
	LOOP
		IF (client.kpp2 IS NOT NULL) THEN
			addAdditionalKpp(client.kpp2, client.owner_id);
		END IF;
		IF (client.kpp3 IS NOT NULL) THEN
			addAdditionalKpp(client.kpp3, client.owner_id);
		END IF;
		IF (client.kpp4 IS NOT NULL) THEN
			addAdditionalKpp(client.kpp4, client.owner_id);
		END IF;
	END LOOP;
	COMMIT;
END;
DROP PROCEDURE addAdditionalKpp
/

