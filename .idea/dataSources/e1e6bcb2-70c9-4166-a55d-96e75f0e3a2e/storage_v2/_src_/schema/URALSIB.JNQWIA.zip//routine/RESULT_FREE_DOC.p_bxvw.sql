create procedure RESULT_FREE_DOC(
Code out INTEGER,
Name VARCHAR,
P_ID VARCHAR
) as
begin
Code := 0;
end;
/

