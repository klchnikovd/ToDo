create procedure sms_newDoc(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
P_Filial VARCHAR,
P_AbsId VARCHAR,
P_sDocumentNumber VARCHAR,
P_dDocumentDate VARCHAR,
P_dDateInp VARCHAR,
P_nService VARCHAR,
P_RecordId VARCHAR,
P_nServiceID VARCHAR,
P_nActivity VARCHAR,
P_sChargeAccount VARCHAR,
P_nKind VARCHAR,
P_sPhone VARCHAR,
P_sPhone2 VARCHAR,
P_nOperationType VARCHAR,
P_nKind2 VARCHAR,
P_nOperationType2 VARCHAR
) as
begin
Refer := 1025;
Code := 3;
Name := 'Тест хранимки';
end;
/

