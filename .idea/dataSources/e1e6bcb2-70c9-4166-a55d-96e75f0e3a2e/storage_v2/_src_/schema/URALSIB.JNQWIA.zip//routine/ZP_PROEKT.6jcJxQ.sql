create procedure zp_proekt(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
sCodeZP VARCHAR,
NreestrType NUMERIC,
sRstrNumer NUMERIC,
dDate VARCHAR,
sNameClient VARCHAR,
nTotalsum NUMERIC,
sDataR CLOB
) as
begin
Refer := 648590;
Code := 1;
Name := 'Тест хранимки';
end;
/

