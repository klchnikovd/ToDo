create procedure transit_newDoc(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
P_Filial VARCHAR,
P_sABSID NUMERIC,
P_sCustomerName VARCHAR,
P_sCustomerINN VARCHAR,
P_sDocumentNumber VARCHAR,
P_dDocumentDate TIMESTAMP,
P_sLicenceNumber VARCHAR,
P_dLicenceDate TIMESTAMP,
P_sSenderOfficial VARCHAR,
P_sPhoneOfficial VARCHAR,
P_nSellPercent NUMERIC,
P_nRequestRate NUMERIC,
P_nRequestRateType NUMERIC,
P_sCurrDealInquiryNumber VARCHAR,
P_dCurrDealInquiryDate TIMESTAMP,
P_sUKNumber VARCHAR,
P_dUKDate TIMESTAMP,
P_sNote VARCHAR,
P_sDealType VARCHAR,
P_sOperCode VARCHAR,
P_sGroundReceipts VARCHAR,
P_nAmountReceipts NUMERIC,
P_nAmountTransfer NUMERIC,
P_nAmountFreeSell NUMERIC,
P_nAmountForSell NUMERIC,
P_nAmountRest NUMERIC,
P_sCurrCode VARCHAR,
P_sAccountTransit VARCHAR,
P_sCustomerBankBIC VARCHAR,
P_sReceiverCurrBIC VARCHAR,
P_sReceiverRurAccount VARCHAR,
P_sReceiverRurBIC VARCHAR,
P_sChargeAccount VARCHAR,
P_dDateInp TIMESTAMP,
P_nService INTEGER,
P_RecordId VARCHAR,
P_sReceiverCurrAccount VARCHAR,
P_sIP VARCHAR,
P_sKEYID VARCHAR
) as
begin
Refer := 648590;
Code := 0;
Name := 'Тест хранимки';
end;
/

