create procedure SPRAVKA_NEW(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
P_Filial VARCHAR,
sABSID VARCHAR,
P_dDocumentDate VARCHAR,
P_DocumentNumber VARCHAR,
P_SenderOfficials VARCHAR,
sINN VARCHAR,
P_DocSposob VARCHAR,
P_sDepart VARCHAR,
P_DocType VARCHAR,
P_sAccountS VARCHAR,
P_dDateBegin VARCHAR,
P_dDateEnd VARCHAR,
P_sAccountK VARCHAR,
P_DocText VARCHAR,
P_FileName VARCHAR,
P_sSign1 VARCHAR,
P_sSign2 VARCHAR,
P_dDateInp VARCHAR,
P_RecordId VARCHAR
) as
begin
Refer := 1025;
Code := 0;
Name := 'Тест хранимки';
end;
/

