create procedure nso_newDoc(
Code out INTEGER,
Name out VARCHAR,
Refer in out VARCHAR,
P_Filial VARCHAR,
P_sCustAbsID VARCHAR,
P_dDocumentDateZ VARCHAR,
P_sDocumentNumber VARCHAR,
P_sDocumentNumber1 VARCHAR,
P_dDocumentDate1 VARCHAR,
P_sCustomerName VARCHAR,
P_sCustomerINN VARCHAR,
P_sCurrentAccount VARCHAR,
P_nAmount VARCHAR,
P_sCurrCode VARCHAR,
P_dDateBegin VARCHAR,
P_dDateEnd VARCHAR,
P_nPercentage VARCHAR,
sStatus VARCHAR,
sComment VARCHAR,
P_dDateInp VARCHAR,
P_RecordId VARCHAR
) as
begin
Refer := 1025;
Code := 2;
Name := 'Тест хранимки';
end;
/

